def main():
    print("Hello from rag-pddf-csv-doc!")


if __name__ == "__main__":
    main()
